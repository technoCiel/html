<?php 
class users extends DB
{
	var $table = "users";
}

?>